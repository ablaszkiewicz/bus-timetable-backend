export class CreateStopDto {
  id: number;
  name: string;
  description: string;
}
